﻿using HospitalManagementUI.Models;

namespace HospitalManagementUI.ViewModel
{
    public class PatientDetailsVM
    {
        public int PatientId { get; set; }
        public string PatientName { get; set; } = null!;

        public int DiseaseId { get; set; }
        public Epilepsy Epilepsy { get; set; }
        public List<int> NCDs { get; set; } = new();
        public List<int> Allergies { get; set; } = new();
        public List<NCD> NCD_Info { get; set; } = new();
        public List<Allergies> Allergy_Info { get; set; } = new();
        public List<Allergies> UnselectedAllergies { get; set; } = new();
        public List<NCD> UnselectedNCDs { get; set; } = new();
    }
}
