﻿namespace HospitalManagementSystem.Models
{
    public enum Epilepsy
    {
        Yes = 0,
        No = 1
    }

}
