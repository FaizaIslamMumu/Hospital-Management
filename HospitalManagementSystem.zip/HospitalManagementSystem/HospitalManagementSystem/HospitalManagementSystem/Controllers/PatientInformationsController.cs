﻿using HospitalManagementSystem.DTOs;
using HospitalManagementSystem.Models;
using HospitalManagementSystem.Repository.Abstraction;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Newtonsoft.Json;
using NuGet.Protocol.Core.Types;
using System.Net;

namespace HospitalManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PatientInformationsController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;
        public PatientInformationsController(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        [HttpGet("disease-list")]
        public async Task<ActionResult<IEnumerable<DiseaseInformation>>> GetDiseaseList()
        {
            return await _unitOfWork.DiseaseInformation.Get();
        }

        [HttpGet("NCD-list")]
        public async Task<ActionResult<IEnumerable<NCD>>> GetNCDList()
        {
            return await _unitOfWork.NCD.Get();
        }

        //[HttpGet("selected-NCD-list/{patientId}")]
        //public async Task<IActionResult> GetSelectedNCDList(int patientId)
        //{
        //    var NcdList =await _unitOfWork.NCD_Details.Get();
        //    var selectedNcdList = NcdList.Where(x=>x.PatientId == patientId).ToList();
        //    return Ok(selectedNcdList);
        //}

        [NonAction]
        public async Task<List<NCD>> selectedNCDList(List<int> ncdIds)
        {
            List<NCD> selectedNcdList = new List<NCD>();
            NCD ncd = new NCD();
            foreach (int ncdId in ncdIds)
            {
                ncd = await _unitOfWork.NCD.GetById(ncdId);
                selectedNcdList.Add(ncd);
            }

            return selectedNcdList;
        }

        [NonAction]
        public async Task<List<NCD>> OthersNCDList(List<int> selectedncdIds)
        {
            List<NCD> othersNcdList = new List<NCD>();
            var selectedncds = await selectedNCDList(selectedncdIds);
            othersNcdList =(await _unitOfWork.NCD.Get()).Except(selectedncds).ToList();
            
            return othersNcdList;
        }

        [NonAction]
        public async Task<List<Allergies>> selectedAllergyList(List<int> allergyIds)
        {
            List<Allergies> selectedAllergyList = new List<Allergies>();
            Allergies allergy = new Allergies();
            foreach (int allergyId in allergyIds)
            {
                allergy = await _unitOfWork.Allergies.GetById(allergyId);
                selectedAllergyList.Add(allergy);
            }

            return selectedAllergyList;
        }

        [NonAction]
        public async Task<List<Allergies>> OthersAllergyList(List<int> selectedAllergyIds)
        {
            List<Allergies> othersAllergyList = new List<Allergies>();
            var selectedallergies = await selectedAllergyList(selectedAllergyIds);
            othersAllergyList = (await _unitOfWork.Allergies.Get()).Except(selectedallergies).ToList();

            return othersAllergyList;
        }


        [HttpGet("allergie-list")]
        public async Task<ActionResult<IEnumerable<Allergies>>> GetAllergieList()
        {
            return await _unitOfWork.Allergies.Get();
        }

        // GET: api/PatientInformations
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PatientInformation>>> GetPatientInformation()
        { 
            var data = await _unitOfWork.PatientInformation.Queryable()
            .Include(x => x.DiseaseInformation).ToListAsync();

            return data;
        }

        // GET: api/PatientInformations/5
        [HttpGet("{id}")]
        public async Task<ActionResult<PatientInformation>> GetPatientInformation(int id)
        {
            
            var patientInformation = await _unitOfWork.PatientInformation.GetById(id);

            if (patientInformation == null)
            {
                return NotFound();
            }

            return patientInformation;
        }

        //[HttpGet("Details/{id}")]
        //public async Task<ActionResult<PatientInformationDTO>> GetPatientDetails(int id)
        //{
        //    var patientInfo = await _unitOfWork.PatientInformation.GetById(id);
        //    var diseaseInfo = await _unitOfWork.DiseaseInformation.GetById(patientInfo.DiseaseId);
        //    var ncds = await _unitOfWork.NCD_Details.Get();
        //    var ncdInfo = ncds.Where(x => x.PatientId == id).Select(x=>x.NCDId).ToList();
        //    var selectedNcds = await selectedNCDList(ncdInfo);
        //    var allergies = await _unitOfWork.Allergies_Details.Get();
        //    var allergyInfo = allergies.Where(x=>x.PatientId == id).Select(x=>x.AllergiesId).ToList();

        //    PatientInformationDTO info = new PatientInformationDTO
        //    {
        //        PatientId = id,
        //        PatientName = patientInfo.PatientName,
        //        DiseaseId = diseaseInfo.DiseaseId,
        //        Epilepsy = patientInfo.Epilepsy,
        //        NCDs = ncdInfo,
        //        Allergies = allergyInfo
        //    };

        //    return info;
        //}

        [HttpGet("Details/{id}")]
        public async Task<ActionResult<PatientDetailsDTO>> GetPatientDetails(int id)
        {
            var patientInfo = await _unitOfWork.PatientInformation.GetById(id);
            var diseaseInfo = await _unitOfWork.DiseaseInformation.GetById(patientInfo.DiseaseId);

            var ncds = await _unitOfWork.NCD_Details.Get();
            var ncdInfo = ncds.Where(x => x.PatientId == id).Select(x => x.NCDId).ToList();
            var selectedNcds = await selectedNCDList(ncdInfo);
            var otherNcds = await OthersNCDList(ncdInfo);

            var allergies = await _unitOfWork.Allergies_Details.Get();
            var allergyInfo = allergies.Where(x => x.PatientId == id).Select(x => x.AllergiesId).ToList();
            var selectedAllergies = await selectedAllergyList(allergyInfo);
            var otherAllergies = await OthersAllergyList(allergyInfo);

            PatientDetailsDTO info = new PatientDetailsDTO
            {
                PatientId = id,
                PatientName = patientInfo.PatientName,
                DiseaseId = diseaseInfo.DiseaseId,
                Epilepsy = patientInfo.Epilepsy,
                NCDs = ncdInfo,
                Allergies = allergyInfo,
                NCD_Info = selectedNcds,
                Allergy_Info = selectedAllergies,
                UnselectedAllergies = otherAllergies,
                UnselectedNCDs = otherNcds
            };

            return info;
        }



        // PUT: api/PatientInformations/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutPatientInformation(int id, PatientDetailsDTO patientDetails)
        {
            if (id != patientDetails.PatientId)
            {
                return BadRequest();
            }

            try
            {
                await _unitOfWork.BeginTransactionAsync();

                PatientInformation patientInformation = new PatientInformation
                {
                    PatientId = id,
                    PatientName = patientDetails.PatientName,
                    DiseaseId = patientDetails.DiseaseId,
                    Epilepsy = patientDetails.Epilepsy
                };
                _unitOfWork.PatientInformation.Update(patientInformation);
                await _unitOfWork.SaveChangesAsync();

                

                if (patientDetails.NCDs.Any())
                {
                    var existingNcdDetails = (await _unitOfWork.NCD_Details.Get()).Where(x => x.PatientId == id).ToList();
                    if (existingNcdDetails.Count > 0)
                    {
                        foreach (var ncdDetail in existingNcdDetails)
                        {
                            _unitOfWork.NCD_Details.Delete(ncdDetail.NCD_DetailsId);
                            await _unitOfWork.SaveChangesAsync();
                        }
                    }

                    List<NCD_Details> NCDList = new();
                    patientDetails.NCDs.ForEach(x =>
                    {
                        NCD_Details NCDDetails = new()
                        {
                            PatientId = patientInformation.PatientId,
                            NCDId = x
                        };
                        NCDList.Add(NCDDetails);
                    });
                    await _unitOfWork.NCD_Details.AddRangeAsync(NCDList);
                    await _unitOfWork.SaveChangesAsync();

                    //NCD_Details ncds = new NCD_Details();
                    //List<NCD_Details> ncdList = new List<NCD_Details>();
                    //foreach (var ncd in patientDetails.NCDs)
                    //{
                    //    ncds.NCDId = ncd;
                    //    ncds.PatientId = patientDetails.PatientId;

                    //    ncdList.Add(ncds);
                    //}
                    //await _unitOfWork.NCD_Details.AddRangeAsync(ncdList);
                    //await _unitOfWork.SaveChangesAsync();
                }
                else
                {
                    var existingNcdDetails = (await _unitOfWork.NCD_Details.Get()).Where(x => x.PatientId == id).ToList();
                    if (existingNcdDetails.Count > 0)
                    {
                        foreach (var ncdDetail in existingNcdDetails)
                        {
                            _unitOfWork.NCD_Details.Delete(ncdDetail.NCD_DetailsId);
                            await _unitOfWork.SaveChangesAsync();
                        }
                    }
                }

                if (patientDetails.Allergies.Any())
                {

                    var existingAllergyDetails = (await _unitOfWork.Allergies_Details.Get()).Where(x => x.PatientId == id).ToList();
                    if (existingAllergyDetails.Count > 0)
                    {
                        foreach (var allergyDetail in existingAllergyDetails)
                        {
                            _unitOfWork.Allergies_Details.Delete(allergyDetail.Allergies_DetailsId);
                            await _unitOfWork.SaveChangesAsync();
                        }
                    }

                    if (patientDetails.Allergies.Any())
                    {
                        List<Allergies_Details> allergieList = new();
                        patientDetails.Allergies.ForEach(x =>
                        {
                            Allergies_Details allergieDetails = new()
                            {
                                PatientId = patientInformation.PatientId,
                                AllergiesId = x
                            };
                            allergieList.Add(allergieDetails);
                        });
                        await _unitOfWork.Allergies_Details.AddRangeAsync(allergieList);
                        await _unitOfWork.SaveChangesAsync();
                    }
                    //Allergies_Details allergies = new Allergies_Details();
                    //List<Allergies_Details> allergyList = new List<Allergies_Details>();
                    //foreach (var allergy in patientDetails.Allergies)
                    //{
                    //    allergies.AllergiesId = allergy;
                    //    allergies.PatientId = patientDetails.PatientId;

                    //    allergyList.Add(allergies);
                    //}
                    //await _unitOfWork.Allergies_Details.AddRangeAsync(allergyList);
                    //await _unitOfWork.SaveChangesAsync();
                }
                else
                {
                    var existingAllergyDetails = (await _unitOfWork.Allergies_Details.Get()).Where(x => x.PatientId == id).ToList();
                    if (existingAllergyDetails.Count > 0)
                    {
                        foreach (var allergyDetail in existingAllergyDetails)
                        {
                            _unitOfWork.Allergies_Details.Delete(allergyDetail.Allergies_DetailsId);
                            await _unitOfWork.SaveChangesAsync();
                        }
                    }

                }

                await _unitOfWork.CommitTransactionAsync();
                return Ok();

            }
            catch (Exception)
            {
                await _unitOfWork.RollBackTransactionAsync();
                return BadRequest();
            }

        }

        // POST: api/PatientInformations
        [HttpPost("add-patient")]
        public async Task<ActionResult<PatientInformation>> PostPatientInformation([FromBody] PatientInformationDTO patientDTO)
        {
            var transaction = _unitOfWork.BeginTransactionAsync();

            try
            {
                // Add patient

                PatientInformation patient = new()
                {
                    PatientName = patientDTO.PatientName,
                    DiseaseId = patientDTO.DiseaseId,
                    Epilepsy = patientDTO.Epilepsy
                };

                await _unitOfWork.PatientInformation.AddAsync(patient);
                await _unitOfWork.SaveChangesAsync();

                //Add NCD Detail
                if (patientDTO.NCDs.Any())
                {
                    List<NCD_Details> NCDList = new();
                    patientDTO.NCDs.ForEach(x =>
                    {
                        NCD_Details NCDDetails = new()
                        {
                            PatientId = patient.PatientId,
                            NCDId = x
                        };
                        NCDList.Add(NCDDetails);
                    });
                    await _unitOfWork.NCD_Details.AddRangeAsync(NCDList);
                    await _unitOfWork.SaveChangesAsync();
                }

                //Add Allergie Detail
                if (patientDTO.Allergies.Any())
                {
                    List<Allergies_Details> allergieList = new();
                    patientDTO.Allergies.ForEach(x =>
                    {
                        Allergies_Details allergieDetails = new()
                        {
                            PatientId = patient.PatientId,
                            AllergiesId = x
                        };
                        allergieList.Add(allergieDetails);
                    });
                    await _unitOfWork.Allergies_Details.AddRangeAsync(allergieList);
                    await _unitOfWork.SaveChangesAsync();
                }

                await _unitOfWork.CommitTransactionAsync();
                return StatusCode((int)HttpStatusCode.OK);

            }
            catch (Exception)
            {
                await _unitOfWork.RollBackTransactionAsync();
                return BadRequest();
            }
        }

        // DELETE: api/PatientInformations/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePatientInformation(int id)
        {
            if (_unitOfWork.PatientInformation == null)
            {
                return NotFound();
            }
            var patientInformation = await _unitOfWork.PatientInformation.GetById(id);
            if (patientInformation == null)
            {
                return NotFound();
            }

            _unitOfWork.PatientInformation.Delete(id);
            await _unitOfWork.SaveChangesAsync();

            return NoContent();
        }

        private bool PatientInformationExists(int id)
        {
            return (_unitOfWork.PatientInformation?.GetById(id) != null) ? true : false;
        }
    }
}
