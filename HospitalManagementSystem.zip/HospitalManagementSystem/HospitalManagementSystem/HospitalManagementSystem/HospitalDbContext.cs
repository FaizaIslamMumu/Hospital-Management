﻿using HospitalManagementSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace HospitalManagementSystem
{
    public class HospitalDbContext : DbContext
    {
        public HospitalDbContext(DbContextOptions<HospitalDbContext> options) : base(options)
        {

        }

        public DbSet<PatientInformation> PatientInformation { get; set; }
        public DbSet<DiseaseInformation> DiseaseInformation { get; set; }
        public DbSet<NCD> NCD { get; set; }
        public DbSet<NCD_Details> NCDDetails { get; set; }
        public DbSet<Allergies> Allergies { get; set; }
        public DbSet<Allergies_Details> Allergies_details { get; set; }
 
    }
}
